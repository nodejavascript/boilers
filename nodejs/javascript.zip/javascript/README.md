# README

- Please uncomment `# .env` from `.gitignore`

`.env` was saved with `NODE_ENV=development` to accommodate this nodemon restart policy:

```
{
  "env": {
    "NODE_ENV": "development"
  }
}

```
